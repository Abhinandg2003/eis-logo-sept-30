import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ScenarioDemo } from "@/components/home/ScenarioDemo";
import { InsightCard } from "@/components/insights/InsightCard";
import { CtaBand } from "@/components/sections/CtaBand";
import { insights } from "@/lib/cms";
import { site } from "@/lib/site";
import { IoIosArrowRoundForward } from "react-icons/io";
import { MdOutlineArrowOutward } from "react-icons/md";
import { ScrollPoints } from "@/components/home/ScrollPoints";

// All copy below is PLACEHOLDER: edit freely.
const views = [
  {
    title: "For employees",
    text: "See how you approach hard calls. Your score is a mirror for reflection and growth, not a ranking.",
  },
  {
    title: "For employers",
    text: "See patterns across scenarios: how people prioritise, communicate and handle trade-offs. Signals, not verdicts.",
  },
];
const steps = [
  {
    title: "A scenario appears",
    text: "Realistic, ambiguous situations drawn from real workplaces.",
  },
  {
    title: "Someone responds",
    text: "There is no single right answer. Every choice is meaningful.",
  },
  {
    title: "The score updates",
    text: "Each response moves several dimensions, read from either point of view.",
  },
];

const three = [
  {
    title: "Behavioural",
  },
  {
    title: "Contextual",
  },
  {
    title: "Third",
  },
];
const delay = (n: number) => ({ "--i": n }) as React.CSSProperties; // stagger for .rise

export default async function Home() {
  const latest = (await insights.list()).slice(0, 3); // CMS provider (static for now)

  return (
    <>
      {/* Hero: text + interactive scenario */}
      <section className="section h-auto !pt-0 sm:!pt-0 !pb-0">
        {/* <div className="h-[140vh] absolute top-0 opacity-10 w-full bg-[radial-gradient(ellipse_100%_100%_at_50%_0%,#FFA022_0%,#FFA022_10%,#fff_70%)]" /> */}
        <div className="container-x flex flex-col items-center gap-12 pt-10 lg:grid-cols-2 lg:gap-16  justify-center mx-auto">
          <div className=" !flex !flex-col !items-center !justify-center pt-5">
            <div className="flex gap-2 relative items-center pl-3 pr-[0.4rem] py-[0.4rem] border border-black/8 rounded-full mb-10">
              <p className="rounded-full bg-[var(--color-brand)]/10 text-[0.8rem] text-[var(--color-brand)] px-2">
                New
              </p>
              <p className="flex items-center gap-2 text-center text-[0.9rem] ">
                Meet Ei 1.1 <span className="font-light">Our new model</span>{" "}
                <MdOutlineArrowOutward className="bg-black/5 h-[25px] w-[25px] rounded-full p-[0.4rem] text-sm " />
              </p>
            </div>
            <h1 className="h-display !text-center !flex !justify-center rise">
              Measure how people decide, not just what they know.
            </h1>
            <p
              className="lead !text-black text-center rise mt-6"
              style={delay(1)}
            >
              {site.fullName} Measure how people make better decisions.
            </p>
            <div
              className="rise mt-8 mb-10 flex flex-wrap gap-3"
              style={delay(2)}
            >
              <Button className="group" asChild>
                <Link href={site.cta.href}>
                  {site.cta.label}{" "}
                  <span className="ml-1 my-auto justify-center flex items-center">
                    {" "}
                    <IoIosArrowRoundForward className="group-hover:translate-x-1 ease-out transition-all duration-200" />
                  </span>
                </Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/insights">Read insights</Link>
              </Button>
            </div>

            <div className="w-[70%] rounded-3xl h-[60vh] mt-10  overflow-hidden">
              <img
                src="/images/hero.jpg"
                className="w-full object-cover "
                alt=""
              />
            </div>
          </div>
          <div className="rise" style={delay(3)}>
            {/* <ScenarioDemo /> */}
          </div>
        </div>
      </section>

      {/* Two points of view */}
      {/* <section className="section  bg-neutral-50">
        <div className="container-x">
          <h2 className="h-section max-w-[24ch]">
            One score, two ways of reading it
          </h2>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {views.map((v) => (
              <div key={v.title} className="surface p-7">
                <h3 className="font-display text-xl font-semibold">
                  {v.title}
                </h3>
                <p className="mt-3 leading-relaxed text-neutral-600">
                  {v.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section> */}

      {/* How it works: a real sequence, so numbering is meaningful here */}
      <div className="my-15">
        <section className="section h-[100vh] flex items-center">
          <div className="container-x">
            <div className="grid grid-cols-2 w-full ">
              <div>
                <h2 className="h-section !text-start !text-5xl font-normal">
                  One Test <br /> Every Aspect
                </h2>
                <ScrollPoints points={three} />

                <div
                  className="rise mt-8 mb-10 flex flex-wrap gap-3"
                  style={delay(2)}
                >
                  <Button className="group" asChild>
                    <Link href={site.cta.href}>
                      {site.cta.label}{" "}
                      <span className="ml-1 my-auto justify-center flex items-center">
                        {" "}
                        <IoIosArrowRoundForward className="group-hover:translate-x-1 ease-out transition-all duration-200" />
                      </span>
                    </Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link href="/insights">Read insights</Link>
                  </Button>
                </div>
              </div>
              <div className="bg-black relative h-full w-full ">
                <div>
                  <img
                    src="/images/eyes.jpg"
                    className="object-cover  absolute inset-0 h-full w-full  z-1"
                    alt=""
                  />
                  <div className="absolute left-0 bottom-0  bg-white h-4 w-4 z-5"></div>
                  <div className="absolute left-4 bottom-4  bg-white h-4 w-4 z-5"></div>

                  <div className="absolute left-0 top-0  bg-white h-4 w-4 z-5"></div>
                  <div className="absolute left-4 top-4  bg-white h-4 w-4 z-5"></div>

                  <div className="absolute right-0 top-0  bg-white h-4 w-4 z-5"></div>
                  <div className="absolute right-4 top-4  bg-white h-4 w-4 z-5"></div>

                  <div className="absolute right-0 bottom-0  bg-white h-4 w-4 z-5"></div>
                  <div className="absolute right-4 bottom-4  bg-white h-4 w-4 z-5"></div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Latest insights (from CMS layer) */}
      <section className="section !pt-0 !my-15">
        <div className="container-x">
          <div className="flex items-end justify-end gap-4">
            <h2 className="h-section absolute left-1/2 -translate-x-1/2  !text-center">
              Latest insights
            </h2>
            <Link
              href="/insights"
              className="text-sm text-neutral-600 underline-offset-4 hover:text-neutral-900 hover:underline"
            >
              View all
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {latest.map((p) => (
              <InsightCard key={p.slug} post={p} />
            ))}
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
